/*
		Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Amazon Software License (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/asl/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, express or implied. See the License for the specific language governing permissions and limitations under the License. 
 */

/*
 * May 2015
 * Derivative created by HP, to leverage and extend the function framework to provide automatic loading from S3, via Lambda, to the HP Vertica Analytic Database platform.
 */


// custom defaults for setup.js - overrides standard defaults in defaults.js 
// uncomment settings as desired below, and provide your own values. 

//dfltRegion = 'us-east-1';
dfltS3Prefix = 'bstrahan/db_ingest' ;
//dfltS3MountDir = '/mnt/s3/';
//dfltFilenameFilter = '.*\.csv';
dfltClusterEndpoint = 'ec2-50-16-232-141.compute-1.amazonaws.com' ;
//dfltClusterPort = '5433';
dfltUserName = 'dbadmin' ;
dfltUserPwd = 'password' ;
dfltTable = 'banking_batch' ;
dfltCopyOptions = 'parser fdelimitedparser(delimiter=\',\')' ;
//dfltPreLoadStatement = OPTIONAL_BLANK ;
//dfltPostLoadStatement = OPTIONAL_BLANK ;
//dfltBatchSize = '1';
//dfltBatchTimeoutSecs = '30';
dfltSuccessTopic = 'arn:aws:sns:us-east-1:482855101108:LambdaDBLoadOK' ;
dfltFailureTopic = 'arn:aws:sns:us-east-1:482855101108:LambdaDBLoadFAIL' ;

